**Kreise**

Kreise sind ein Feature um die Sichtbarkeit einer Kreisnachricht (Posts) festzulegen. Nur die User welche in einen Kreis einsortiert wurden, können die für diesen Kreis freigegebenen Posts sehen. Kreise werden beim schreiben einer Kreisnachricht ausgewählt. Der Standartkreis ist public.

--

**Kreismanagement**

Es können auf der Übersichtseite über alle Kreise beliebig viele neue Kreise angelegt werden oder alte Kreise wieder gelöscht werden. Dort ist auch eine Liste aller Kreise mit ihrem jeweiligen Namen zu finden.

--

**Kreisdetails**

Auf der Detailseite eines Kreises ist eine Übersicht über die in diesen Kreis einsortierten User zu finden. Dort können auch weitere User zu diesem Kreis hinzugefügt werden oder wieder entfernt werden. Es existiert zudem eine Übersicht über alle Posts die für diesen Kreis freigegeben wurden.