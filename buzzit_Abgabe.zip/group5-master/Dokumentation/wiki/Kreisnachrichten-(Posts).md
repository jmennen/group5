User könne Kreisnachrichten (Posts) schreiben. Diese können entweder öffentlich sein oder an eine beliebe Anzahl eigener Kreise adressiert werden. Diese Posts werden im Stream der eigenen Follower und beim Aufrufen des eigenen Profils angezeigt.

Beim Verfassen von Posts ist zudem das markieren von Usern mit dem "@"-Sysmbol und das setzen von Themen mit dem "#"-Symbol möglich.