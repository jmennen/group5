def get_db_config():
    return {
        'default': {
            'ENGINE': 'django.db.backends.mysql',
            'NAME': 'sn',
            'USER': 'sn',
            'PASSWORD': 'UniAOSJOPEhS1PFFQaUyH4ftyhkUIOKH',
            'HOST': 'vps146949.ovh.net',  # Or an IP Address that your DB is hosted on
            'PORT': '3306',
        }
    }
