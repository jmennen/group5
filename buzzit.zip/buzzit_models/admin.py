from django.contrib import admin
from .models import *

admin.site.register(Profile)
admin.site.register(Circle)
admin.site.register(Message)
admin.site.register(Circle_message)
admin.site.register(Directmessage)
admin.site.register(Theme)
admin.site.register(Settings)